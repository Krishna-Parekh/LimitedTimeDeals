import sys
sys.path.append("/Users/krishna/Desktop")

class DealProducts(object):  # Deals
	def __init__(self):
		self.id = None
		self.name = None
		self.quantity = None
		self.endTime = None   # "DD-MM-YYYY HH:MM:SS"
		self.price = None
		self.status = None  # ACTIVE / INACTIVE

	def setId(self, id):
		self.id = id

	def getId(self):
		return self.id

	def setName(self, name):
		self.name = name

	def getName(self):
		return self.name

	def setQuantity(self, quantity):
		self.quantity = quantity

	def getQuantity(self):
		return self.quantity

	def setEndTime(self, endTime):
		self.endTime = endTime

	def getEndTime(self):
		return self.endTime

	def setPrice(self, price):
		self.price = price

	def getPrice(self):
		return self.price

	def setStatus(self, status):
		self.status = status

	def getStatus(self):
		return self.status