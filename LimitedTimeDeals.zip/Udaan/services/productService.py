# from Udaan.model.customer import DealProducts

class ProductService:
	dealProductsList = {}

	def __init__(self):
		pass

	def addDealProduct(self, productId, name, qty, endTime, price):
		prod = DealProducts()
		prod.setId(productId)
		prod.setName(name)
		prod.setQuantity(qty)
		prod.setEndTime(endTime)
		prod.setPrice(price)
		prod.setStatus("ACTIVE")
		dealProductsList[productId] = prod



