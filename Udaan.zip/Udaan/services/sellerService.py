from Udaan.model.customer import Seller
# from Udaan.model.customer import DealProducts
from Udaan.services.productService import ProductService

class SellerServices:
	sellers = {}
	sellerId = 1

	def __init__(self):
		pass

	def addSeller(self, name, id=None):
		if not id:
			id = sellerId
			sellerId += 1
		if id not in sellers:
			slr = Seller()
			slr.setName(name)
			slr.setId(id)
			sellers[id] = slr
		else:
			print("Invalid id!!")

	def addProduct(self, sellerId, productId, name, qty, endTime, price):
		if productId in ProductService.__class__.dealProductsList :
			if sellerId in sellers and productId in sellers[sellerId].products:
				print("Product is already added by seller!!")
			else:
				sellers[sellerId].addProduct(productId)
				ProductService.addDealProduct(productId, name, qty, endTime, price)
		else:
			print("Product already exists!!")

	def endDeal(self, productId):
		if productId in ProductService.__class__.dealProductsList:
			ProductService.__class__.dealProductsList[productId].setStatus("INACTIVE")
		else:
			print("Invalid product id !!")

	def updateQtyByNum(self, productId, qtyToAdd):
		if productId in ProductService.__class__.dealProductsList and ProductService.__class__.dealProductsList[productId].getStatus() == "ACTIVE":
			currQty = ProductService.__class__.dealProductsList[productId].getQuantity()
			ProductService.__class__.dealProductsList[productId].setQuantity(currQty + qtyToAdd)
		else:
			print("Invalid product id !!")

	def updateEndTime(self, productId, time):   # "DD-MM-YYYY HH:MM:SS"
		if productId in ProductService.__class__.dealProductsList and ProductService.__class__.dealProductsList[productId].getStatus() == "ACTIVE":
			ProductService.__class__.dealProductsList[productId].setEndTime(time)
		else:
			print("Invalid product id !!")


