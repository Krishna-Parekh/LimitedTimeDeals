from Udaan.model.customer import Customer
# from Udaan.model.customer import DealProducts


class CustomerServices:
	customers = {}
	customerId = 1

	def __init__(self):
		pass

	def addCustomer(self, name, id=None):
		if not id:
			id = customerId
			customerId += 1
		if id not in customers:
			cust = Customer()
			cust.setName(name)
			cust.setId(id)
			customers[id] = cust
		else:
			print("Invalid id!!")

	def claimDeal(self, customerId, productId, qty):
		if qty > 1:
			print("Quantity limit is 1...")
		if productId in ProductService.__class__.dealProductsList:
			if customerId in customers and productId in customers[customerId].products:
				print("Product is already taken by customer!!")
			else:
				
				currQty = ProductService.__class__.dealProductsList[productId].getQuantity()
				if currQty == 0:

				else:
					customers[customerId].addProduct(productId)
					ProductService.__class__.dealProductsList[productId].setQuantity(currQty - 1)
		else:
			print("Product doesn't exist!!")



