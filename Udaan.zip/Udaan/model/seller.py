
import sys
sys.path.append("/Users/krishna/Desktop")

class Seller(object):
	def __init__(self):
		self.id = None
		self.name = None
		self.products = []

	def setId(self, id):
		self.id = id

	def getId(self):
		return self.id

	def setName(self, name):
		self.name = name

	def getName(self):
		return self.name

	def addProduct(self, id):
		self.products.append(id)

	def getProducts(self):
		return self.products
