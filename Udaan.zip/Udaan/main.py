import sys
sys.path.append("/Users/krishna/Desktop")

from Udaan.services.productService import ProductService
from Udaan.services.customerService import CustomerService
from Udaan.services.sellerService import SellerService

cusServ = CustomerService()
prodServ = ProductService()
selServ = SellerService()

cusServ.addCustomer("KAP")
print("customer added!!")